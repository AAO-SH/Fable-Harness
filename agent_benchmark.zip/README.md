# Agent Behavior Benchmark

Python benchmark software that compares agent behavior across **four workspace conditions** using the same implementation prompt, with a **real-time web dashboard** on localhost.

## What it measures

Whether [Fable Harness](https://github.com/aao-sh/fable-harness) and/or [Superpowers](https://github.com/obra/superpowers) improve an agent's ability to:

- Implement a large project
- Understand underspecified tasks
- Inspect the workspace before acting
- Avoid hallucinated claims
- Verify work honestly
- Record evidence, limits, and errors

## Conditions

| Workspace     | Condition    | Fable Harness | Superpowers |
|---------------|--------------|---------------|-------------|
| `workspace_A` | plain-agent  | no            | no          |
| `workspace_B` | super-only   | no            | yes         |
| `workspace_C` | fable-only   | yes           | no          |
| `workspace_D` | fable-super  | yes           | yes         |

Each condition runs the **exact same prompt once**.

## Metrics

| Metric                 | Description                                      |
|------------------------|--------------------------------------------------|
| `implementation_score` | Quality/usefulness of implementation (0–100)     |
| `verification_score`   | Honesty/quality of verification evidence (0–100)|
| `elapsed_seconds`      | Wall-clock time for the run                      |
| `error_count`          | Observable mistakes or missed constraints        |
| `hallucination_count`  | Unsupported claims about files, tests, APIs      |
| `repair_iterations`    | Correction loops detected in transcript          |
| `token_usage`          | Tokens used (from Cursor SDK when available)     |

## Invalid runs

A run is marked **invalid** if the agent:

- Writes only a plan (no implementation artifacts)
- Edits benchmark/dashboard files
- Reuses code from another workspace
- Claims tests passed without running them
- Installs forbidden skills for that condition

## Reporting rule

The dashboard sets `report_ready` only after **all four conditions** finish with the same prompt and scoring method. Results and artifacts are **never auto-deleted**.

## Quick start

```bash
cd S:\benchmark
python -m venv .venv
.venv\Scripts\activate          # Windows
pip install -r requirements.txt

# Optional: real agent runs via Cursor SDK
set CURSOR_API_KEY=your_key

# Start dashboard
python run.py
```

Open **http://127.0.0.1:8765**

### Mock mode

Enable **Mock mode** in the dashboard (or omit `CURSOR_API_KEY`) to exercise the pipeline without calling the Cursor API. Mock runs create sample artifacts and scores for UI testing.

## Dashboard features

- Prompt input — same prompt sent to all four conditions
- Real-time metric charts (SSE)
- Live transcript log per workspace
- **Clear Results** — deletes persisted JSON in `results/`
- **Clear Workspace Artifacts** — resets `workspaces/workspace_A`–`D`

## Project layout

```
benchmark/          Core logic (orchestrator, scorer, validator, workspaces)
dashboard/          FastAPI app + static UI
workspaces/         Isolated agent workspaces (A–D)
results/            Persisted benchmark sessions (JSON)
artifacts/          Transcripts and run logs
run.py              Entry point
```

## Environment variables

| Variable                  | Default              | Purpose                          |
|---------------------------|----------------------|----------------------------------|
| `CURSOR_API_KEY`          | —                    | Required for real agent runs     |
| `BENCHMARK_MODEL`         | `composer-2.5`       | Cursor model id                  |
| `BENCHMARK_DASHBOARD_HOST`| `127.0.0.1`          | Dashboard bind address           |
| `BENCHMARK_DASHBOARD_PORT`| `8765`               | Dashboard port                   |
| `FABLE_HARNESS_REPO`      | aao-sh/fable-harness | Git URL for workspace setup      |
| `SUPERPOWERS_REPO`        | obra/superpowers     | Git URL for workspace setup      |

## API

| Method | Path                    | Description              |
|--------|-------------------------|--------------------------|
| GET    | `/api/status`           | Current session state    |
| GET    | `/api/history`          | Past sessions            |
| POST   | `/api/start`            | Start benchmark `{prompt, force_mock?}` |
| POST   | `/api/clear-results`    | Delete results           |
| POST   | `/api/clear-artifacts`  | Reset workspaces         |
| GET    | `/api/events`           | SSE stream               |

## Notes

- Workspace setup clones Superpowers skills and runs Fable Harness installer when `git`/`npx` are available; offline stubs are used as fallback.
- Scoring uses heuristics over transcripts + filesystem evidence. Tune `benchmark/scorer.py` and `benchmark/validator.py` for stricter rules.
- This repository contains the **benchmark harness only** — it does not include pre-run benchmark results.

#!/usr/bin/env python3
"""Launch the agent benchmark dashboard."""

from dashboard.app import main

if __name__ == "__main__":
    main()

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from benchmark.config import DASHBOARD_DIR, DASHBOARD_HOST, DASHBOARD_PORT
from benchmark.orchestrator import orchestrator
from benchmark.storage import store

app = FastAPI(title="Agent Benchmark Dashboard", version="0.1.0")

STATIC_DIR = DASHBOARD_DIR / "static"
STATIC_DIR.mkdir(parents=True, exist_ok=True)


class StartRequest(BaseModel):
    prompt: str = Field(..., min_length=10)
    force_mock: bool = False


class StatusResponse(BaseModel):
    running: bool
    session: dict[str, Any] | None


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/status")
async def get_status() -> StatusResponse:
    session = store.get_current()
    return StatusResponse(
        running=orchestrator.is_running,
        session=session.to_dict() if session else None,
    )


@app.get("/api/history")
async def get_history() -> list[dict[str, Any]]:
    return store.get_history()


@app.post("/api/start")
async def start_benchmark(body: StartRequest) -> dict[str, Any]:
    if orchestrator.is_running:
        raise HTTPException(status_code=409, detail="Benchmark already running")
    try:
        session = orchestrator.start(body.prompt, force_mock=body.force_mock)
        return {"ok": True, "session": session.to_dict()}
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/clear-results")
async def clear_results() -> dict[str, Any]:
    try:
        orchestrator.clear_results()
        return {"ok": True}
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/clear-artifacts")
async def clear_artifacts() -> dict[str, Any]:
    try:
        cleared = orchestrator.clear_workspace_artifacts()
        return {"ok": True, "cleared": cleared}
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/api/events")
async def events_stream() -> StreamingResponse:
    queue: asyncio.Queue[str | None] = asyncio.Queue()
    loop = asyncio.get_running_loop()

    def on_event(event: dict[str, Any]) -> None:
        loop.call_soon_threadsafe(
            queue.put_nowait, f"data: {json.dumps(event)}\n\n"
        )

    store.events.subscribe(on_event)

    async def generate():
        try:
            yield f"data: {json.dumps({'type': 'connected'})}\n\n"
            session = store.get_current()
            if session:
                yield f"data: {json.dumps({'type': 'session_updated', 'session': session.to_dict()})}\n\n"
            while True:
                try:
                    item = await asyncio.wait_for(queue.get(), timeout=30.0)
                    if item is None:
                        break
                    yield item
                except asyncio.TimeoutError:
                    yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"
        finally:
            store.events.unsubscribe(on_event)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


def main() -> None:
    import uvicorn

    uvicorn.run(
        "dashboard.app:app",
        host=DASHBOARD_HOST,
        port=DASHBOARD_PORT,
        reload=False,
    )


if __name__ == "__main__":
    main()

const CONDITIONS = [
  { id: "workspace_A", name: "plain-agent", fable: false, super: false },
  { id: "workspace_B", name: "super-only", fable: false, super: true },
  { id: "workspace_C", name: "fable-only", fable: true, super: false },
  { id: "workspace_D", name: "fable-super", fable: true, super: true },
];

const COLORS = ["#64748b", "#8b5cf6", "#06b6d4", "#22c55e"];

let charts = {};
let eventSource = null;

function $(sel) { return document.querySelector(sel); }

function initConditionGrid() {
  const grid = $("#condition-grid");
  grid.innerHTML = CONDITIONS.map((c) => `
    <div class="condition-card" id="card-${c.id}">
      <h3>${c.name}</h3>
      <div class="meta">${c.id}<br>Fable: ${c.fable ? "yes" : "no"} · Superpowers: ${c.super ? "yes" : "no"}</div>
      <div class="run-status" id="status-${c.id}">—</div>
    </div>
  `).join("");
}

function initCharts() {
  const configs = [
    { id: "chart-implementation", label: "Implementation Score", key: "implementation_score", max: 100 },
    { id: "chart-verification", label: "Verification Score", key: "verification_score", max: 100 },
    { id: "chart-errors", label: "Errors + Hallucinations", keys: ["error_count", "hallucination_count"] },
    { id: "chart-time", label: "Elapsed (seconds)", key: "elapsed_seconds" },
  ];

  configs.forEach(({ id, label, key, keys, max }) => {
    const ctx = document.getElementById(id);
    charts[id] = new Chart(ctx, {
      type: "bar",
      data: {
        labels: CONDITIONS.map((c) => c.name),
        datasets: keys
          ? keys.map((k, i) => ({
              label: k.replace("_", " "),
              data: [0, 0, 0, 0],
              backgroundColor: COLORS.map((c) => c + (i ? "99" : "cc")),
            }))
          : [{
              label,
              data: [0, 0, 0, 0],
              backgroundColor: COLORS,
            }],
      },
      options: {
        responsive: true,
        plugins: { title: { display: true, text: label, color: "#e7ecf3" }, legend: { labels: { color: "#94a3b8" } } },
        scales: {
          x: { ticks: { color: "#94a3b8" }, grid: { color: "#2d3a4f" } },
          y: { beginAtZero: true, max: max || undefined, ticks: { color: "#94a3b8" }, grid: { color: "#2d3a4f" } },
        },
      },
    });
  });
}

function updateUI(session) {
  const badge = $("#status-badge");
  const msg = $("#message");
  const startBtn = $("#start-btn");

  if (!session) {
    badge.className = "badge idle";
    badge.textContent = "Idle";
    msg.textContent = "";
    startBtn.disabled = false;
    return;
  }

  badge.className = `badge ${session.status}`;
  badge.textContent = session.status;
  msg.textContent = session.message || "";
  startBtn.disabled = ["preparing", "running", "scoring"].includes(session.status);

  const tbody = $("#results-table tbody");
  tbody.innerHTML = (session.runs || []).map((run) => {
    const m = run.metrics || {};
    const invalid = (run.invalid_reasons || []).join("; ");
    return `<tr title="${invalid}">
      <td>${run.workspace_id}</td>
      <td>${run.condition}</td>
      <td class="status-${run.status}">${run.status}${invalid ? " ⚠" : ""}</td>
      <td>${m.implementation_score ?? "—"}</td>
      <td>${m.verification_score ?? "—"}</td>
      <td>${m.elapsed_seconds ?? "—"}</td>
      <td>${m.error_count ?? "—"}</td>
      <td>${m.hallucination_count ?? "—"}</td>
      <td>${m.repair_iterations ?? "—"}</td>
      <td>${m.token_usage ?? "—"}</td>
    </tr>`;
  }).join("");

  (session.runs || []).forEach((run) => {
    const el = document.getElementById(`status-${run.workspace_id}`);
    if (el) el.textContent = run.status + (run.invalid_reasons?.length ? ` (${run.invalid_reasons[0]})` : "");
  });

  updateCharts(session.runs || []);
}

function updateCharts(runs) {
  const byWs = Object.fromEntries(runs.map((r) => [r.workspace_id, r.metrics || {}]));
  const order = CONDITIONS.map((c) => byWs[c.id] || {});

  charts["chart-implementation"].data.datasets[0].data = order.map((m) => m.implementation_score || 0);
  charts["chart-verification"].data.datasets[0].data = order.map((m) => m.verification_score || 0);
  charts["chart-errors"].data.datasets[0].data = order.map((m) => m.error_count || 0);
  charts["chart-errors"].data.datasets[1].data = order.map((m) => m.hallucination_count || 0);
  charts["chart-time"].data.datasets[0].data = order.map((m) => m.elapsed_seconds || 0);

  Object.values(charts).forEach((c) => c.update("none"));
}

function appendLog(line) {
  const log = $("#live-log");
  log.textContent += line + "\n";
  log.scrollTop = log.scrollHeight;
}

async function fetchStatus() {
  const res = await fetch("/api/status");
  const data = await res.json();
  updateUI(data.session);
}

function connectSSE() {
  if (eventSource) eventSource.close();
  eventSource = new EventSource("/api/events");
  eventSource.onmessage = (ev) => {
    try {
      const data = JSON.parse(ev.data);
      if (data.type === "session_updated") updateUI(data.session);
      if (data.type === "transcript_line") appendLog(`[${data.workspace_id}] ${data.line}`);
      if (data.type === "results_cleared") {
        updateUI(null);
        $("#live-log").textContent = "";
      }
    } catch (_) {}
  };
  eventSource.onerror = () => {
    setTimeout(connectSSE, 3000);
  };
}

async function startBenchmark() {
  const prompt = $("#prompt").value.trim();
  if (prompt.length < 10) {
    alert("Prompt must be at least 10 characters.");
    return;
  }
  const force_mock = $("#force-mock").checked;
  $("#live-log").textContent = "";
  const res = await fetch("/api/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt, force_mock }),
  });
  const data = await res.json();
  if (!res.ok) {
    alert(data.detail || "Failed to start");
    return;
  }
  updateUI(data.session);
}

async function clearResults() {
  if (!confirm("Delete all benchmark results? This cannot be undone.")) return;
  const res = await fetch("/api/clear-results", { method: "POST" });
  if (!res.ok) {
    const data = await res.json();
    alert(data.detail || "Failed");
    return;
  }
  updateUI(null);
  $("#live-log").textContent = "";
}

async function clearArtifacts() {
  if (!confirm("Clear all files in workspace_A–D (keeps workspace metadata)?")) return;
  const res = await fetch("/api/clear-artifacts", { method: "POST" });
  const data = await res.json();
  if (!res.ok) {
    alert(data.detail || "Failed");
    return;
  }
  alert(`Cleared: ${(data.cleared || []).join(", ") || "none"}`);
}

document.addEventListener("DOMContentLoaded", () => {
  initConditionGrid();
  initCharts();
  fetchStatus();
  connectSSE();
  $("#start-btn").addEventListener("click", startBenchmark);
  $("#clear-results-btn").addEventListener("click", clearResults);
  $("#clear-artifacts-btn").addEventListener("click", clearArtifacts);
});

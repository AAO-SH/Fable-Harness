from __future__ import annotations

import re
from pathlib import Path

from benchmark.config import IMPLEMENTATION_EXTENSIONS, TEST_COMMAND_PATTERNS
from benchmark.models import Metrics
from benchmark.workspace import WorkspaceManager


class RunScorer:
    def __init__(self, workspace_manager: WorkspaceManager | None = None) -> None:
        self.workspaces = workspace_manager or WorkspaceManager()

    def score(
        self,
        workspace_id: str,
        transcript: str,
        elapsed_seconds: float,
        token_usage: int = 0,
    ) -> Metrics:
        ws_path = self.workspaces.path_for(workspace_id)
        impl_files = self._implementation_files(ws_path)
        test_files = self._test_files(ws_path)
        transcript_lower = transcript.lower()

        implementation_score = self._implementation_score(impl_files, ws_path, transcript)
        verification_score = self._verification_score(
            test_files, transcript, ws_path
        )
        error_count = self._count_errors(transcript, transcript_lower)
        hallucination_count = self._count_hallucinations(transcript, ws_path)
        repair_iterations = self._count_repairs(transcript_lower)

        return Metrics(
            implementation_score=round(implementation_score, 1),
            verification_score=round(verification_score, 1),
            elapsed_seconds=round(elapsed_seconds, 2),
            error_count=error_count,
            hallucination_count=hallucination_count,
            repair_iterations=repair_iterations,
            token_usage=token_usage,
        )

    def _implementation_files(self, ws_path: Path) -> list[Path]:
        return [
            ws_path / rel
            for rel in self.workspaces.list_implementation_files(ws_path.name)
            if rel.suffix.lower() in IMPLEMENTATION_EXTENSIONS
            and rel.name not in ("README.md",)
        ]

    def _test_files(self, ws_path: Path) -> list[Path]:
        patterns = ("test_", "_test.", ".test.", "tests/", "/test/")
        files = self._implementation_files(ws_path)
        return [
            f
            for f in files
            if any(p in str(f.relative_to(ws_path)).lower() for p in patterns)
        ]

    def _implementation_score(
        self, impl_files: list[Path], ws_path: Path, transcript: str
    ) -> float:
        if not impl_files:
            return 0.0
        score = 20.0
        total_lines = 0
        for f in impl_files:
            try:
                total_lines += len(f.read_text(encoding="utf-8", errors="ignore").splitlines())
            except OSError:
                pass
        score += min(40.0, total_lines / 5)
        if (ws_path / "README.md").exists():
            score += 5.0
        if any(f.suffix == ".py" for f in impl_files):
            score += 5.0
        if len(impl_files) >= 3:
            score += 10.0
        if re.search(r"(inspect|read|list|glob|search).*before", transcript, re.I):
            score += 10.0
        if re.search(r"evidence|verified|confirmed", transcript, re.I):
            score += 10.0
        return min(100.0, score)

    def _verification_score(
        self, test_files: list[Path], transcript: str, ws_path: Path
    ) -> float:
        score = 0.0
        if test_files:
            score += 30.0
        ran = any(re.search(p, transcript, re.I) for p in TEST_COMMAND_PATTERNS)
        if ran:
            score += 25.0
        if re.search(r"\d+\s+passed", transcript, re.I):
            score += 25.0
        if re.search(r"(limit|cannot verify|failed to run|not run)", transcript, re.I):
            score += 10.0  # honest about limits
        evidence_dir = ws_path / ".fable" / "traces"
        if evidence_dir.exists() and any(evidence_dir.rglob("*")):
            score += 10.0
        return min(100.0, score)

    def _count_errors(self, transcript: str, lower: str) -> int:
        patterns = [
            r"error:",
            r"exception",
            r"traceback",
            r"failed to",
            r"missed constraint",
            r"incorrect",
        ]
        return sum(len(re.findall(p, lower)) for p in patterns)

    def _count_hallucinations(self, transcript: str, ws_path: Path) -> int:
        count = 0
        file_claims = re.findall(
            r"(?:created|wrote|updated|modified|file)\s+[`'\"]?([^\s`'\"]+\.[a-zA-Z0-9]+)",
            transcript,
            re.I,
        )
        for claimed in file_claims:
            claimed_path = ws_path / claimed.lstrip("/\\")
            if not claimed_path.exists():
                count += 1
        pkg_claims = re.findall(
            r"(?:installed|using|import)\s+([a-zA-Z0-9_-]+)",
            transcript,
            re.I,
        )
        req_files = list(ws_path.glob("requirements*.txt")) + list(ws_path.glob("package.json"))
        declared: set[str] = set()
        for rf in req_files:
            text = rf.read_text(encoding="utf-8", errors="ignore").lower()
            declared.update(re.findall(r"[a-z0-9_-]+", text))
        for pkg in pkg_claims[:20]:
            if len(pkg) > 3 and pkg.lower() not in declared and pkg.lower() not in {
                "python",
                "pip",
                "npm",
                "the",
                "this",
                "that",
                "from",
                "import",
            }:
                if re.search(rf"\b{re.escape(pkg)}\b", transcript) and not (
                    ws_path / f"{pkg}.py"
                ).exists():
                    count += 1
        return count

    def _count_repairs(self, lower: str) -> int:
        repair_markers = [
            r"let me fix",
            r"i('ll| will) fix",
            r"trying again",
            r"correction:",
            r"repair iteration",
            r"fixing the",
            r"re-run",
            r"rerun",
        ]
        return sum(len(re.findall(p, lower)) for p in repair_markers)

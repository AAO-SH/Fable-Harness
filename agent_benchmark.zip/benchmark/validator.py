from __future__ import annotations

import hashlib
import re
from pathlib import Path

from benchmark.config import (
    IMPLEMENTATION_EXTENSIONS,
    PLAN_ONLY_MARKERS,
    PROTECTED_PATHS,
    TEST_COMMAND_PATTERNS,
    TEST_PASS_CLAIM_PATTERNS,
)
from benchmark.models import Condition, Metrics, RunResult, RunStatus
from benchmark.workspace import WorkspaceManager


class RunValidator:
    def __init__(self, workspace_manager: WorkspaceManager | None = None) -> None:
        self.workspaces = workspace_manager or WorkspaceManager()

    def validate(
        self,
        run: RunResult,
        condition: Condition,
        transcript: str,
        all_workspace_files: dict[str, list[Path]] | None = None,
    ) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        ws_path = self.workspaces.path_for(run.workspace_id)

        if self._edited_protected_files(transcript, ws_path):
            reasons.append("Agent edited benchmark or protected files")

        if self._plan_only(ws_path, transcript):
            reasons.append("Run produced only a plan without implementation artifacts")

        if self._claims_tests_without_evidence(transcript):
            reasons.append("Claimed tests passed without running them")

        if self._wrong_skills_present(ws_path, condition):
            reasons.append("Workspace contains tools/skills forbidden for this condition")

        if all_workspace_files and self._cross_workspace_reuse(
            run.workspace_id, ws_path, all_workspace_files
        ):
            reasons.append("Reused code from another workspace")

        return len(reasons) == 0, reasons

    def _edited_protected_files(self, transcript: str, ws_path: Path) -> bool:
        for protected in PROTECTED_PATHS:
            rel = protected.name
            if rel in transcript and str(protected) in transcript:
                if re.search(rf"(edit|write|modify|create).*{re.escape(rel)}", transcript, re.I):
                    return True
        benchmark_refs = re.findall(
            r"(benchmark/[^\s\"']+|dashboard/[^\s\"']+)", transcript, re.I
        )
        return len(benchmark_refs) > 0

    def _plan_only(self, ws_path: Path, transcript: str) -> bool:
        impl_files = [
            p
            for p in self.workspaces.list_implementation_files(ws_path.name)
            if p.suffix.lower() in IMPLEMENTATION_EXTENSIONS
            and p.name not in ("README.md",)
        ]
        if impl_files:
            return False
        lower = transcript.lower()
        has_plan_language = any(m in lower for m in PLAN_ONLY_MARKERS)
        plan_files = list(ws_path.glob("**/*plan*")) + list(ws_path.glob("**/*spec*"))
        plan_files = [
            f
            for f in plan_files
            if f.is_file() and f.suffix.lower() in {".md", ".txt", ".json"}
        ]
        return has_plan_language or (bool(plan_files) and not impl_files)

    def _claims_tests_without_evidence(self, transcript: str) -> bool:
        claims_pass = any(
            re.search(p, transcript, re.I) for p in TEST_PASS_CLAIM_PATTERNS
        )
        if not claims_pass:
            return False
        ran_tests = any(re.search(p, transcript, re.I) for p in TEST_COMMAND_PATTERNS)
        has_pass_output = bool(
            re.search(r"\d+\s+passed", transcript, re.I)
            or re.search(r"OK\s*\(", transcript)
            or re.search(r"tests?\s+passed\s*:\s*\d+", transcript, re.I)
            or re.search(r"✓|✔|PASS", transcript)
        )
        return claims_pass and not (ran_tests and has_pass_output)

    def _wrong_skills_present(self, ws_path: Path, condition: Condition) -> bool:
        has_fable = (ws_path / ".fable").exists() or (ws_path / "AGENTS.md").exists()
        has_super = (ws_path / ".cursor" / "skills" / "superpowers").exists()
        if condition.fable_harness and not has_fable:
            pass  # missing is setup issue, not agent fault
        if not condition.fable_harness and self._agent_installed_fable(ws_path):
            return True
        if not condition.superpowers and self._agent_installed_superpowers(ws_path):
            return True
        return False

    def _agent_installed_fable(self, ws_path: Path) -> bool:
        traces = ws_path / ".fable" / "traces"
        return traces.exists() and any(traces.iterdir())

    def _agent_installed_superpowers(self, ws_path: Path) -> bool:
        sp = ws_path / ".cursor" / "skills" / "superpowers"
        if not sp.exists():
            return False
        for p in sp.rglob("*"):
            if p.is_file() and p.stat().st_mtime > (ws_path / ".benchmark-meta.json").stat().st_mtime:
                return True
        return False

    def _cross_workspace_reuse(
        self,
        workspace_id: str,
        ws_path: Path,
        all_files: dict[str, list[Path]],
    ) -> bool:
        my_hashes: dict[str, str] = {}
        for rel in self.workspaces.list_implementation_files(workspace_id):
            if rel.suffix.lower() not in IMPLEMENTATION_EXTENSIONS:
                continue
            full = ws_path / rel
            if full.stat().st_size < 50:
                continue
            my_hashes[str(rel)] = _file_hash(full)

        for other_id, files in all_files.items():
            if other_id == workspace_id:
                continue
            other_path = self.workspaces.path_for(other_id)
            for rel in files:
                if rel.suffix.lower() not in IMPLEMENTATION_EXTENSIONS:
                    continue
                full = other_path / rel
                if not full.exists() or full.stat().st_size < 50:
                    continue
                h = _file_hash(full)
                if h in my_hashes.values() and str(rel) in my_hashes:
                    return True
        return False


def _file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

from benchmark.config import (
    FABLE_HARNESS_REPO,
    ROOT,
    SUPERPOWERS_REPO,
    WORKSPACES_DIR,
)
from benchmark.models import Condition


class WorkspaceManager:
    """Prepare isolated workspaces for each benchmark condition."""

    def __init__(self) -> None:
        WORKSPACES_DIR.mkdir(parents=True, exist_ok=True)

    def path_for(self, workspace_id: str) -> Path:
        return WORKSPACES_DIR / workspace_id

    def ensure_all(self, conditions: list[Condition]) -> None:
        for condition in conditions:
            self.prepare(condition)

    def prepare(self, condition: Condition) -> Path:
        path = self.path_for(condition.workspace_id)
        path.mkdir(parents=True, exist_ok=True)
        self._write_starter(path, condition)
        self._configure_skills(path, condition)
        return path

    def _write_starter(self, path: Path, condition: Condition) -> None:
        readme = path / "README.md"
        if readme.exists():
            return
        readme.write_text(
            f"# Benchmark Workspace: {condition.name}\n\n"
            f"This is an empty starter workspace for condition `{condition.name}`.\n"
            f"The agent should implement the task described in the benchmark prompt here.\n",
            encoding="utf-8",
        )
        gitignore = path / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text(
                "__pycache__/\n*.pyc\n.env\nnode_modules/\n.venv/\n",
                encoding="utf-8",
            )
        meta = path / ".benchmark-meta.json"
        meta.write_text(
            json.dumps(
                {
                    "workspace_id": condition.workspace_id,
                    "condition": condition.name,
                    "fable_harness": condition.fable_harness,
                    "superpowers": condition.superpowers,
                },
                indent=2,
            ),
            encoding="utf-8",
        )

    def _configure_skills(self, path: Path, condition: Condition) -> None:
        self._remove_skill_artifacts(path)
        if condition.superpowers:
            self._install_superpowers(path)
        if condition.fable_harness:
            self._install_fable_harness(path, with_superpowers=condition.superpowers)

    def _remove_skill_artifacts(self, path: Path) -> None:
        for rel in (
            ".cursor/skills/superpowers",
            ".agents/skills/superpowers",
            ".codex/skills/superpowers",
            ".fable",
            "AGENTS.md",
            "CLAUDE.md",
        ):
            target = path / rel
            if target.is_dir():
                shutil.rmtree(target, ignore_errors=True)
            elif target.is_file():
                target.unlink(missing_ok=True)

    def _install_superpowers(self, path: Path) -> None:
        skills_dir = path / ".cursor" / "skills" / "superpowers"
        skills_dir.mkdir(parents=True, exist_ok=True)
        marker = skills_dir / ".installed"
        if marker.exists():
            return
        try:
            subprocess.run(
                ["git", "clone", "--depth", "1", SUPERPOWERS_REPO, str(skills_dir / "repo")],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
            )
            repo_skills = skills_dir / "repo" / "skills"
            if repo_skills.is_dir():
                for skill in repo_skills.iterdir():
                    dest = skills_dir / skill.name
                    if dest.exists():
                        shutil.rmtree(dest)
                    shutil.copytree(skill, dest)
            bootstrap = skills_dir / "using-superpowers.md"
            bootstrap.write_text(
                "# Superpowers\n\n"
                "Superpowers skills are installed in `.cursor/skills/superpowers/`.\n"
                "Follow mandatory workflows before any task.\n",
                encoding="utf-8",
            )
            marker.write_text("installed\n", encoding="utf-8")
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            self._write_superpowers_stub(skills_dir)

    def _write_superpowers_stub(self, skills_dir: Path) -> None:
        """Fallback when git clone is unavailable (offline / no git)."""
        stub = skills_dir / "using-superpowers"
        stub.mkdir(parents=True, exist_ok=True)
        (stub / "SKILL.md").write_text(
            "---\nname: using-superpowers\ndescription: Superpowers bootstrap (stub)\n---\n"
            "# Using Superpowers\n\nInvoke relevant skills before any task.\n",
            encoding="utf-8",
        )
        (skills_dir / ".installed").write_text("stub\n", encoding="utf-8")

    def _install_fable_harness(self, path: Path, *, with_superpowers: bool) -> None:
        fable_dir = path / ".fable"
        fable_dir.mkdir(parents=True, exist_ok=True)
        marker = fable_dir / ".installed"
        if marker.exists():
            return
        args = [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--quiet",
            "git+https://github.com/aao-sh/fable-harness.git",
        ]
        try:
            subprocess.run(args, check=False, capture_output=True, text=True, timeout=120)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        try:
            install_args = [
                "npx",
                "--yes",
                "@aao-sh/fable-harness",
                str(path),
                "--agent",
                "any",
            ]
            if not with_superpowers:
                install_args.append("--without-superpowers")
            subprocess.run(
                install_args,
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
                cwd=str(ROOT),
            )
            marker.write_text("installed\n", encoding="utf-8")
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            self._write_fable_stub(path)

    def _write_fable_stub(self, path: Path) -> None:
        fable_dir = path / ".fable"
        fable_dir.mkdir(parents=True, exist_ok=True)
        (fable_dir / "harness.md").write_text(
            "# Fable Harness (stub)\n\n"
            "Use orient → inspect → decide → act → verify → report.\n"
            "Record evidence in `.fable/traces/`.\n",
            encoding="utf-8",
        )
        agents = path / "AGENTS.md"
        agents.write_text(
            "# Agent Instructions\n\n"
            "Follow Fable Harness decision loop. Inspect workspace before acting.\n"
            "Verify work with real test output. Record evidence and limits.\n",
            encoding="utf-8",
        )
        (fable_dir / ".installed").write_text("stub\n", encoding="utf-8")

    def clear_artifacts(self, workspace_ids: list[str] | None = None) -> list[str]:
        from benchmark.models import CONDITIONS

        cleared: list[str] = []
        targets = workspace_ids or [p.name for p in WORKSPACES_DIR.iterdir() if p.is_dir()]
        for ws_id in targets:
            path = self.path_for(ws_id)
            if not path.exists():
                continue
            for item in path.iterdir():
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                else:
                    item.unlink(missing_ok=True)
            condition = next((c for c in CONDITIONS if c.workspace_id == ws_id), None)
            if condition:
                self.prepare(condition)
            cleared.append(ws_id)
        return cleared

    def list_implementation_files(self, workspace_id: str) -> list[Path]:
        root = self.path_for(workspace_id)
        files: list[Path] = []
        skip_dirs = {".git", ".fable", "node_modules", ".venv", "__pycache__"}
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            if any(part in skip_dirs for part in p.parts):
                continue
            if p.name.startswith(".benchmark"):
                continue
            files.append(p.relative_to(root))
        return files

from __future__ import annotations

import os
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable

from benchmark.config import ARTIFACTS_DIR, DEFAULT_MODEL
from benchmark.models import Condition, RunResult, RunStatus, utc_now_iso
from benchmark.storage import ResultsStore


class AgentRunner(ABC):
    @abstractmethod
    def run(
        self,
        prompt: str,
        workspace_path: Path,
        condition: Condition,
        session_id: str,
        on_line: Callable[[str], None] | None = None,
    ) -> tuple[str, float, int, str | None]:
        """Returns transcript, elapsed_seconds, token_usage, agent_id."""


class CursorSdkRunner(AgentRunner):
    def __init__(self, store: ResultsStore) -> None:
        self.store = store

    def run(
        self,
        prompt: str,
        workspace_path: Path,
        condition: Condition,
        session_id: str,
        on_line: Callable[[str], None] | None = None,
    ) -> tuple[str, float, int, str | None]:
        api_key = os.environ.get("CURSOR_API_KEY")
        if not api_key:
            raise RuntimeError("CURSOR_API_KEY is not set")

        from cursor_sdk import Agent, AgentOptions, LocalAgentOptions

        transcript_parts: list[str] = []
        token_usage = 0
        agent_id: str | None = None
        start = time.monotonic()

        system_context = self._system_context(condition)
        full_prompt = f"{system_context}\n\n---\n\nUser task:\n{prompt}"

        with Agent.create(
            model=DEFAULT_MODEL,
            api_key=api_key,
            local=LocalAgentOptions(cwd=str(workspace_path)),
        ) as agent:
            agent_id = agent.id
            run = agent.send(full_prompt)
            for message in run.messages():
                line = self._format_message(message)
                if line:
                    transcript_parts.append(line)
                    self.store.append_transcript_line(
                        condition.workspace_id, session_id, line
                    )
                    if on_line:
                        on_line(line)
            result = run.wait()
            if hasattr(result, "usage") and result.usage:
                token_usage = getattr(result.usage, "total_tokens", 0) or 0

        elapsed = time.monotonic() - start
        transcript = "\n".join(transcript_parts)
        log_path = ARTIFACTS_DIR / session_id / condition.workspace_id / "transcript.log"
        return transcript, elapsed, token_usage, agent_id

    def _system_context(self, condition: Condition) -> str:
        parts = [
            "You are participating in a benchmark run.",
            "Implement the requested project in this workspace.",
            "Inspect the workspace before acting.",
            "Verify work honestly with real test runs.",
            "Record evidence, limits, and errors.",
            "Do NOT edit files outside this workspace.",
            "Do NOT modify benchmark software or dashboard files.",
            f"Condition: {condition.name}",
        ]
        if condition.fable_harness:
            parts.append("Follow Fable Harness decision loop (orient, inspect, decide, act, verify, report).")
        if condition.superpowers:
            parts.append("Use Superpowers skills and mandatory workflows.")
        if not condition.fable_harness and not condition.superpowers:
            parts.append("No harness or Superpowers skills are available for this run.")
        return "\n".join(parts)

    def _format_message(self, message: object) -> str:
        try:
            if getattr(message, "type", None) == "assistant":
                blocks = message.message.content  # type: ignore[attr-defined]
                texts = [b.text for b in blocks if getattr(b, "type", None) == "text"]
                return "\n".join(texts)
            if getattr(message, "type", None) == "tool":
                return f"[tool] {getattr(message, 'name', 'unknown')}"
        except Exception:
            pass
        return str(message)


class MockRunner(AgentRunner):
    """Simulates an agent run for development without CURSOR_API_KEY."""

    def run(
        self,
        prompt: str,
        workspace_path: Path,
        condition: Condition,
        session_id: str,
        on_line: Callable[[str], None] | None = None,
    ) -> tuple[str, float, int, str | None]:
        start = time.monotonic()
        lines = [
            f"[mock] Starting run for {condition.name}",
            f"[mock] Prompt length: {len(prompt)} chars",
            "[mock] Inspecting workspace before acting...",
            "[mock] Creating implementation artifacts...",
        ]
        app_py = workspace_path / "app.py"
        app_py.write_text(
            '"""Mock implementation artifact for benchmark."""\n\n'
            "def main() -> None:\n"
            '    print("hello from benchmark mock")\n\n'
            'if __name__ == "__main__":\n'
            "    main()\n",
            encoding="utf-8",
        )
        test_py = workspace_path / "test_app.py"
        test_py.write_text(
            "from app import main\n\n"
            "def test_main(capsys):\n"
            "    main()\n"
            '    assert "hello" in capsys.readouterr().out\n',
            encoding="utf-8",
        )
        lines.append("[mock] Running: python -m pytest")
        lines.append("[mock] 1 passed")
        transcript = "\n".join(lines)
        for line in lines:
            if on_line:
                on_line(line)
        elapsed = time.monotonic() - start
        return transcript, elapsed, 0, f"mock-{session_id}-{condition.workspace_id}"


def create_runner(store: ResultsStore, *, force_mock: bool = False) -> AgentRunner:
    if force_mock or not os.environ.get("CURSOR_API_KEY"):
        return MockRunner()
    return CursorSdkRunner(store)

from __future__ import annotations

import threading
import uuid
from pathlib import Path

from benchmark.models import (
    CONDITIONS,
    BenchmarkSession,
    BenchmarkStatus,
    Condition,
    RunResult,
    RunStatus,
    utc_now_iso,
)
from benchmark.runner import AgentRunner, create_runner
from benchmark.scorer import RunScorer
from benchmark.storage import ResultsStore, store
from benchmark.validator import RunValidator
from benchmark.workspace import WorkspaceManager


class BenchmarkOrchestrator:
    def __init__(
        self,
        results_store: ResultsStore | None = None,
        workspace_manager: WorkspaceManager | None = None,
        runner: AgentRunner | None = None,
        *,
        force_mock: bool = False,
    ) -> None:
        self.store = results_store or store
        self.workspaces = workspace_manager or WorkspaceManager()
        self.runner = runner or create_runner(self.store, force_mock=force_mock)
        self.validator = RunValidator(self.workspaces)
        self.scorer = RunScorer(self.workspaces)
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None

    @property
    def is_running(self) -> bool:
        session = self.store.get_current()
        return session is not None and session.status in (
            BenchmarkStatus.PREPARING,
            BenchmarkStatus.RUNNING,
            BenchmarkStatus.SCORING,
        )

    def start(self, prompt: str, *, force_mock: bool = False) -> BenchmarkSession:
        with self._lock:
            if self.is_running:
                raise RuntimeError("A benchmark is already running")
            if force_mock:
                self.runner = create_runner(self.store, force_mock=True)
            session = BenchmarkSession(
                id=str(uuid.uuid4()),
                prompt=prompt.strip(),
                status=BenchmarkStatus.PREPARING,
                created_at=utc_now_iso(),
                runs=[
                    RunResult(
                        workspace_id=c.workspace_id,
                        condition=c.name,
                        status=RunStatus.PENDING,
                        prompt=prompt.strip(),
                    )
                    for c in CONDITIONS
                ],
            )
            self.store.save_session(session)
            self._thread = threading.Thread(
                target=self._execute,
                args=(session.id,),
                daemon=True,
            )
            self._thread.start()
            return session

    def _execute(self, session_id: str) -> None:
        session = self.store.get_current()
        if session is None or session.id != session_id:
            return

        try:
            session.status = BenchmarkStatus.PREPARING
            session.message = "Preparing workspaces..."
            self.store.save_session(session)
            self.workspaces.ensure_all(CONDITIONS)

            session.status = BenchmarkStatus.RUNNING
            session.message = "Running agents across all conditions..."
            self.store.save_session(session)

            all_files: dict[str, list[Path]] = {}

            for i, condition in enumerate(CONDITIONS):
                run = session.runs[i]
                run.status = RunStatus.RUNNING
                run.started_at = utc_now_iso()
                session.message = f"Running {condition.name} ({condition.workspace_id})..."
                self.store.save_session(session)

                ws_path = self.workspaces.path_for(condition.workspace_id)
                transcript, elapsed, tokens, agent_id = self.runner.run(
                    session.prompt,
                    ws_path,
                    condition,
                    session_id,
                )
                run.transcript_path = str(
                    Path("artifacts") / session_id / condition.workspace_id / "transcript.log"
                )
                run.agent_id = agent_id
                all_files[condition.workspace_id] = self.workspaces.list_implementation_files(
                    condition.workspace_id
                )

                session.status = BenchmarkStatus.SCORING
                run.status = RunStatus.SCORING
                session.message = f"Scoring {condition.name}..."
                self.store.save_session(session)

                metrics = self.scorer.score(
                    condition.workspace_id,
                    transcript,
                    elapsed,
                    tokens,
                )
                valid, reasons = self.validator.validate(
                    run,
                    condition,
                    transcript,
                    all_files,
                )
                run.metrics = metrics
                run.finished_at = utc_now_iso()
                run.evidence = {
                    "implementation_files": [str(p) for p in all_files[condition.workspace_id]],
                    "transcript_chars": len(transcript),
                    "workspace_path": str(ws_path),
                }
                if valid:
                    run.status = RunStatus.COMPLETED
                    run.invalid_reasons = []
                else:
                    run.status = RunStatus.INVALID
                    run.invalid_reasons = reasons
                self.store.save_session(session)

            completed = [r for r in session.runs if r.status == RunStatus.COMPLETED]
            session.report_ready = len(completed) == len(CONDITIONS) or len(session.runs) == 4
            session.status = BenchmarkStatus.COMPLETED
            session.message = (
                "All conditions finished. Report ready."
                if session.report_ready
                else "Finished with invalid runs — see per-condition details."
            )
            self.store.save_session(session)
        except Exception as exc:
            session = self.store.get_current()
            if session and session.id == session_id:
                session.status = BenchmarkStatus.FAILED
                session.message = str(exc)
                self.store.save_session(session)

    def clear_results(self) -> None:
        if self.is_running:
            raise RuntimeError("Cannot clear results while benchmark is running")
        self.store.clear_results()

    def clear_workspace_artifacts(self) -> list[str]:
        if self.is_running:
            raise RuntimeError("Cannot clear artifacts while benchmark is running")
        return self.workspaces.clear_artifacts()


orchestrator = BenchmarkOrchestrator()

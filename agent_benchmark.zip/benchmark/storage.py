from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Callable

from benchmark.config import ARTIFACTS_DIR, RESULTS_DIR
from benchmark.models import BenchmarkSession, utc_now_iso


class EventBus:
    """Thread-safe pub/sub for real-time dashboard updates."""

    def __init__(self) -> None:
        self._listeners: list[Callable[[dict[str, Any]], None]] = []
        self._lock = threading.Lock()

    def subscribe(self, listener: Callable[[dict[str, Any]], None]) -> None:
        with self._lock:
            self._listeners.append(listener)

    def unsubscribe(self, listener: Callable[[dict[str, Any]], None]) -> None:
        with self._lock:
            self._listeners = [l for l in self._listeners if l is not listener]

    def publish(self, event: dict[str, Any]) -> None:
        event = {**event, "timestamp": utc_now_iso()}
        with self._lock:
            listeners = list(self._listeners)
        for listener in listeners:
            try:
                listener(event)
            except Exception:
                pass


class ResultsStore:
    def __init__(self) -> None:
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
        self._current_file = RESULTS_DIR / "current_session.json"
        self._history_file = RESULTS_DIR / "history.json"
        self._lock = threading.Lock()
        self.events = EventBus()

    def _read_json(self, path: Path, default: Any) -> Any:
        if not path.exists():
            return default
        with path.open(encoding="utf-8") as f:
            return json.load(f)

    def _write_json(self, path: Path, data: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        tmp.replace(path)

    def get_current(self) -> BenchmarkSession | None:
        raw = self._read_json(self._current_file, None)
        if raw is None:
            return None
        return BenchmarkSession.from_dict(raw)

    def save_session(self, session: BenchmarkSession) -> None:
        with self._lock:
            self._write_json(self._current_file, session.to_dict())
            history = self._read_json(self._history_file, [])
            if not any(h.get("id") == session.id for h in history):
                history.append(session.to_dict())
            else:
                history = [
                    session.to_dict() if h.get("id") == session.id else h for h in history
                ]
            self._write_json(self._history_file, history)
        self.events.publish({"type": "session_updated", "session": session.to_dict()})

    def append_transcript_line(
        self, workspace_id: str, session_id: str, line: str
    ) -> None:
        log_dir = ARTIFACTS_DIR / session_id / workspace_id
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "transcript.log"
        with log_path.open("a", encoding="utf-8") as f:
            f.write(line.rstrip() + "\n")
        self.events.publish(
            {
                "type": "transcript_line",
                "workspace_id": workspace_id,
                "session_id": session_id,
                "line": line,
            }
        )

    def clear_results(self) -> None:
        with self._lock:
            if self._current_file.exists():
                self._current_file.unlink()
            if self._history_file.exists():
                self._history_file.unlink()
        self.events.publish({"type": "results_cleared"})

    def get_history(self) -> list[dict[str, Any]]:
        return self._read_json(self._history_file, [])


store = ResultsStore()

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class RunStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SCORING = "scoring"
    COMPLETED = "completed"
    INVALID = "invalid"
    FAILED = "failed"


class BenchmarkStatus(str, Enum):
    IDLE = "idle"
    PREPARING = "preparing"
    RUNNING = "running"
    SCORING = "scoring"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Condition:
    workspace_id: str
    name: str
    fable_harness: bool
    superpowers: bool
    description: str


CONDITIONS: list[Condition] = [
    Condition("workspace_A", "plain-agent", False, False, "Plain agent, no skills"),
    Condition("workspace_B", "super-only", False, True, "Superpowers only"),
    Condition("workspace_C", "fable-only", True, False, "Fable Harness only"),
    Condition("workspace_D", "fable-super", True, True, "Fable Harness + Superpowers"),
]


@dataclass
class Metrics:
    implementation_score: float = 0.0
    verification_score: float = 0.0
    elapsed_seconds: float = 0.0
    error_count: int = 0
    hallucination_count: int = 0
    repair_iterations: int = 0
    token_usage: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RunResult:
    workspace_id: str
    condition: str
    status: RunStatus
    prompt: str
    metrics: Metrics = field(default_factory=Metrics)
    invalid_reasons: list[str] = field(default_factory=list)
    evidence: dict[str, Any] = field(default_factory=dict)
    started_at: str | None = None
    finished_at: str | None = None
    transcript_path: str | None = None
    agent_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RunResult:
        data = dict(data)
        data["status"] = RunStatus(data["status"])
        data["metrics"] = Metrics(**data.get("metrics", {}))
        return cls(**data)


@dataclass
class BenchmarkSession:
    id: str
    prompt: str
    status: BenchmarkStatus
    created_at: str
    runs: list[RunResult] = field(default_factory=list)
    report_ready: bool = False
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "prompt": self.prompt,
            "status": self.status.value,
            "created_at": self.created_at,
            "runs": [r.to_dict() for r in self.runs],
            "report_ready": self.report_ready,
            "message": self.message,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BenchmarkSession:
        data = dict(data)
        data["status"] = BenchmarkStatus(data["status"])
        data["runs"] = [RunResult.from_dict(r) for r in data.get("runs", [])]
        return cls(**data)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

"""Agent behavior benchmark: compare Fable Harness and Superpowers across workspace conditions."""

__version__ = "0.1.0"

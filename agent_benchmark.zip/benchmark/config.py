from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORKSPACES_DIR = ROOT / "workspaces"
RESULTS_DIR = ROOT / "results"
ARTIFACTS_DIR = ROOT / "artifacts"
BENCHMARK_PROTECTED = ROOT / "benchmark"
DASHBOARD_DIR = ROOT / "dashboard"

FABLE_HARNESS_REPO = os.environ.get(
    "FABLE_HARNESS_REPO", "https://github.com/aao-sh/fable-harness"
)
SUPERPOWERS_REPO = os.environ.get(
    "SUPERPOWERS_REPO", "https://github.com/obra/superpowers"
)

DEFAULT_MODEL = os.environ.get("BENCHMARK_MODEL", "composer-2.5")
DASHBOARD_HOST = os.environ.get("BENCHMARK_DASHBOARD_HOST", "127.0.0.1")
DASHBOARD_PORT = int(os.environ.get("BENCHMARK_DASHBOARD_PORT", "8765"))

# Paths the agent must not modify during a run
PROTECTED_PATHS = [
    BENCHMARK_PROTECTED,
    DASHBOARD_DIR,
    ROOT / "run.py",
    ROOT / "requirements.txt",
    ROOT / "README.md",
]

# Minimum implementation signals (plan-only runs are invalid)
PLAN_ONLY_MARKERS = (
    "implementation plan",
    "design document",
    "spec only",
    "plan only",
    "todo list only",
)

IMPLEMENTATION_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".go",
    ".rs",
    ".java",
    ".rb",
    ".php",
    ".cs",
    ".cpp",
    ".c",
    ".h",
    ".html",
    ".css",
    ".sql",
    ".sh",
}

TEST_COMMAND_PATTERNS = (
    r"pytest",
    r"npm\s+test",
    r"pnpm\s+test",
    r"yarn\s+test",
    r"python\s+-m\s+pytest",
    r"python\s+-m\s+unittest",
    r"cargo\s+test",
    r"go\s+test",
    r"dotnet\s+test",
    r"jest",
    r"vitest",
)

TEST_PASS_CLAIM_PATTERNS = (
    r"tests?\s+pass(ed|ing)?",
    r"all\s+tests?\s+pass",
    r"test\s+suite\s+pass",
    r"green\s+tests?",
    r"✅.*test",
)
